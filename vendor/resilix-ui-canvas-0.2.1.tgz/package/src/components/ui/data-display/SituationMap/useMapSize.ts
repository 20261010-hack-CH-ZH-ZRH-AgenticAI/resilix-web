import { useEffect, useState } from "react";

export function useMapSize() {
  const [element, ref] = useState<SVGSVGElement | null>(null);
  const [aspect, setAspect] = useState(1200 / 700);
  useEffect(() => {
    if (!element || typeof ResizeObserver === "undefined") return;
    const update = () => {
      const { width, height } = element.getBoundingClientRect();
      if (width > 0 && height > 0) setAspect(width / height);
    };
    const observer = new ResizeObserver(update);
    observer.observe(element);
    update();
    return () => observer.disconnect();
  }, [element]);
  return { ref, aspect };
}
