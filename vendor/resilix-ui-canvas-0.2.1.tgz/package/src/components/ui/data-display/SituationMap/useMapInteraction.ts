import { type KeyboardEvent, type PointerEvent, useRef } from "react";
import type { MapPosition, MapViewport } from "./MapTypes";
import { positionAt } from "./viewport";

function point(event: PointerEvent<SVGSVGElement>): [number, number] {
  const svg = event.currentTarget;
  const matrix = svg.getScreenCTM();
  if (matrix) {
    const p = svg.createSVGPoint();
    p.x = event.clientX;
    p.y = event.clientY;
    const local = p.matrixTransform(matrix.inverse());
    return [local.x, local.y];
  }
  const box = svg.getBoundingClientRect();
  return [
    ((event.clientX - box.left) * 1200) / box.width,
    ((event.clientY - box.top) * 700) / box.height,
  ];
}

function keyAction(
  event: KeyboardEvent<SVGSVGElement>,
  view: MapViewport,
  move: (offset: [number, number]) => void,
  zoom: (delta: number) => void,
  pick?: (value: MapPosition) => void,
) {
  if (event.target !== event.currentTarget) return;
  const direction = {
    ArrowLeft: [-100, 0],
    ArrowRight: [100, 0],
    ArrowUp: [0, -100],
    ArrowDown: [0, 100],
  }[event.key];
  if (direction)
    move([view.offset[0] + direction[0], view.offset[1] + direction[1]]);
  else if (event.key === "+" || event.key === "=") zoom(1);
  else if (event.key === "-") zoom(-1);
  else if (event.key === "Enter" && pick) pick(positionAt(600, 350, view));
  else return;
  event.preventDefault();
}

export function useMapInteraction(
  view: MapViewport,
  move: (offset: [number, number]) => void,
  zoom: (delta: number) => void,
  pick?: (value: MapPosition) => void,
) {
  const drag = useRef<
    | { pointer: number; start: [number, number]; offset: [number, number] }
    | undefined
  >(undefined);
  const onPointerDown = (event: PointerEvent<SVGSVGElement>) => {
    if (event.button !== 0) return;
    drag.current = {
      pointer: event.pointerId,
      start: point(event),
      offset: view.offset,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onPointerMove = (event: PointerEvent<SVGSVGElement>) => {
    if (drag.current?.pointer !== event.pointerId) return;
    const [x, y] = point(event);
    move([
      drag.current.offset[0] - x + drag.current.start[0],
      drag.current.offset[1] - y + drag.current.start[1],
    ]);
  };
  const onPointerUp = (event: PointerEvent<SVGSVGElement>) => {
    if (drag.current?.pointer !== event.pointerId) return;
    const [x, y] = point(event),
      [sx, sy] = drag.current.start;
    if (Math.hypot(x - sx, y - sy) < 5) pick?.(positionAt(x, y, view));
    drag.current = undefined;
    event.currentTarget.releasePointerCapture(event.pointerId);
  };
  return {
    onPointerDown,
    onPointerMove,
    onPointerUp,
    onPointerCancel: () => {
      drag.current = undefined;
    },
    onKeyDown: (event: KeyboardEvent<SVGSVGElement>) =>
      keyAction(event, view, move, zoom, pick),
  };
}
