import type { ReactNode } from "react";
import styles from "./SituationMapStyles.module.css";
import type { MapModel } from "./useMapModel";

function SourceLink({
  href,
  children,
}: {
  href?: string;
  children: ReactNode;
}) {
  if (!href || !href.startsWith("https://")) return <span>{children}</span>;
  return (
    <a href={href} target="_blank" rel="noopener noreferrer">
      {children}
    </a>
  );
}
export function MapAttribution(model: MapModel) {
  const provenance = model.layers.routes ? model.route?.provenance : undefined;
  return (
    <div className={styles.attribution}>
      <SourceLink href={model.attributionUrl}>{model.attribution}</SourceLink>
      {provenance && (
        <>
          {" "}
          ·{" "}
          <SourceLink href={provenance.attribution_url}>
            {provenance.attribution}
          </SourceLink>{" "}
          ·{" "}
          <SourceLink href={provenance.fix_map_url}>
            {model.labels.fixMap ?? "Fix the map"}
          </SourceLink>
        </>
      )}
    </div>
  );
}
