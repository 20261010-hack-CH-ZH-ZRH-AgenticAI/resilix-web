import type { MapModel } from "./useMapModel";

export function MapTiles({ view, tileUrl, fail }: MapModel) {
  const tiles: { x: number; y: number; url: string }[] = [];
  const size = 2 ** view.zoom;
  if (tileUrl)
    for (
      let y = Math.floor(view.top / 256);
      y <= Math.floor((view.top + 700) / 256);
      y++
    ) {
      if (y < 0 || y >= size) continue;
      for (
        let x = Math.floor(view.left / 256);
        x <= Math.floor((view.left + 1200) / 256);
        x++
      ) {
        tiles.push({
          x,
          y,
          url: tileUrl
            .replace("{z}", `${view.zoom}`)
            .replace("{x}", `${((x % size) + size) % size}`)
            .replace("{y}", `${y}`),
        });
      }
    }
  return (
    <>
      {tiles.map((tile) => (
        <image
          key={`${view.zoom}-${tile.x}-${tile.y}`}
          href={tile.url}
          crossOrigin="anonymous"
          x={tile.x * 256 - view.left}
          y={tile.y * 256 - view.top}
          width="256"
          height="256"
          onError={fail}
        />
      ))}
    </>
  );
}
