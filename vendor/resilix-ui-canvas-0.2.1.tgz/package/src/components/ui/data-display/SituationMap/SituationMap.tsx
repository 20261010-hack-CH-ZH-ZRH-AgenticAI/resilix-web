"use client";
import { useId } from "react";
import accessStyles from "./MapAccessStyles.module.css";
import { MapAttribution } from "./MapAttribution";
import { MapLayerControls, MapNavigation, MapStatus } from "./MapControls";
import { MapMarkers } from "./MapMarkers";
import { MapPositionLayer } from "./MapPositionLayer";
import { MapRouteLayer } from "./MapRouteLayer";
import { MapTiles } from "./MapTiles";
import type { SituationMapProps } from "./MapTypes";
import styles from "./SituationMapStyles.module.css";
import { useMapModel } from "./useMapModel";

export type { MapMarker, SituationMapProps } from "./MapTypes";

export function SituationMap(props: SituationMapProps) {
  const model = useMapModel(props);
  const hintId = useId();
  return (
    <div className={styles.map}>
      <span id={hintId} className={accessStyles.srOnly}>
        {props.labels.panHint ??
          "Drag or use arrow keys to move the map. Use plus and minus to zoom."}
      </span>
      <svg
        ref={model.ref}
        className={styles.canvas}
        viewBox="0 0 1200 700"
        preserveAspectRatio="xMidYMid slice"
        role="application"
        // biome-ignore lint/a11y/noNoninteractiveTabindex: Interactive map supports keyboard panning, zooming, and coordinate selection.
        tabIndex={0}
        aria-label={props.labels.map}
        aria-describedby={hintId}
        {...model.interaction}
      >
        <title>{props.labels.map}</title>
        <rect width="1200" height="700" className={styles.backdrop} />
        <MapTiles {...model} />
        <MapRouteLayer {...model} />
        <MapMarkers {...model} />
        <MapPositionLayer {...model} />
      </svg>
      <MapLayerControls {...model} />
      <MapNavigation {...model} />
      <MapStatus {...model} />
      <MapAttribution {...model} />
    </div>
  );
}
