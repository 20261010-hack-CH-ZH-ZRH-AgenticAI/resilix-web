import { MapGlyph } from "./MapGlyph";
import styles from "./SituationMapStyles.module.css";
import type { MapModel } from "./useMapModel";
import { routeCoordinates, screenPoint } from "./viewport";

function Endpoint({
  x,
  y,
  end,
  title,
}: {
  x: number;
  y: number;
  end?: boolean;
  title: string;
}) {
  return (
    <g transform={`translate(${x},${y})`} className={styles.endpoint}>
      <title>{title}</title>
      <circle r="18" />
      <foreignObject x="-12" y="-12" width="24" height="24">
        <span className={styles.endpointGlyph}>
          <MapGlyph name={end ? "flag" : "location"} size={22} />
        </span>
      </foreignObject>
    </g>
  );
}
export function MapRouteLayer(model: MapModel) {
  const coordinates = routeCoordinates(model.route);
  if (!model.layers.routes || coordinates.length < 2) return null;
  const points = coordinates.map(([lon, lat]) =>
    screenPoint(lat, lon, model.view),
  );
  const line = points
    .map(([x, y]) => `${x.toFixed(2)},${y.toFixed(2)}`)
    .join(" ");
  const first = points[0],
    last = points[points.length - 1];
  return (
    <g className={styles.route}>
      <title>
        {model.labels.routePreview ?? "Route preview · safety not assessed"}
      </title>
      <polyline points={line} className={styles.routeCasing} />
      <polyline points={line} className={styles.routeLine} />
      <Endpoint
        x={first[0]}
        y={first[1]}
        title={model.labels.start ?? "Route start"}
      />
      <Endpoint
        x={last[0]}
        y={last[1]}
        end
        title={model.labels.end ?? "Route destination"}
      />
    </g>
  );
}
