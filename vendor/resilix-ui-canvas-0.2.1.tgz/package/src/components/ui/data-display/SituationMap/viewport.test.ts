import { expect, test } from "bun:test";
import type { MapRoute, SituationMapProps } from "./MapTypes";
import {
  initialView,
  makeView,
  positionAt,
  routeCoordinates,
  screenPoint,
  zoomView,
} from "./viewport";

const route: MapRoute = {
  id: "provider-fixture",
  geometry: {
    type: "LineString",
    coordinates: [
      [8.5417, 47.3769],
      [8.544, 47.377],
      [8.5481, 47.3763],
    ],
  },
  distance_m: 764.5,
  duration_s: 611.8,
  profile: "foot",
};
const props: SituationMapProps = {
  markers: [],
  onSelect: () => undefined,
  attribution: "Test",
  labels: {
    zoomIn: "+",
    zoomOut: "-",
    reset: "Reset",
    unavailable: "Unavailable",
    map: "Map",
  },
};

test("real route extent fits the map without drawing inferred geometry", () => {
  const view = initialView({ ...props, route });
  for (const [lon, lat] of route.geometry.coordinates) {
    const [x, y] = screenPoint(lat, lon, view);
    expect(x).toBeGreaterThan(0);
    expect(x).toBeLessThan(1200);
    expect(y).toBeGreaterThan(0);
    expect(y).toBeLessThan(700);
  }
  expect(routeCoordinates(route)).toBe(route.geometry.coordinates);
});
test("invalid geometry is rejected as a whole rather than bridged", () => {
  const invalid = {
    ...route,
    geometry: {
      ...route.geometry,
      coordinates: [
        [8, 47],
        [NaN, 47],
        [9, 47],
      ] as [number, number][],
    },
  };
  expect(routeCoordinates(invalid)).toEqual([]);
  expect(routeCoordinates()).toEqual([]);
});

test("route fitting keeps every provider point visible in a narrow phone map", () => {
  const aspect = 300 / 400;
  const view = initialView({ ...props, route }, aspect);
  const visibleWidth = 700 * aspect;
  for (const [lon, lat] of route.geometry.coordinates) {
    const [x] = screenPoint(lat, lon, view);
    expect(x).toBeGreaterThan(600 - visibleWidth / 2);
    expect(x).toBeLessThan(600 + visibleWidth / 2);
  }
});
test("panning and zoom keep screen-to-coordinate selection consistent", () => {
  const view = makeView("test", 13, [47.3769, 8.5417], [120, -80]);
  const position = positionAt(720, 510, view);
  const screen = screenPoint(position.latitude, position.longitude, view);
  expect(screen[0]).toBeCloseTo(720, 6);
  expect(screen[1]).toBeCloseTo(510, 6);
  const before = positionAt(600, 350, view),
    after = positionAt(600, 350, zoomView(view, 2));
  expect(after.latitude).toBeCloseTo(before.latitude, 6);
  expect(after.longitude).toBeCloseTo(before.longitude, 6);
});
test("routes crossing the antimeridian fit the nearby world copy", () => {
  const crossing: MapRoute = {
    ...route,
    geometry: {
      type: "LineString",
      coordinates: [
        [179.9, 0],
        [-179.9, 0],
      ],
    },
  };
  const view = initialView({ ...props, route: crossing });
  const [a] = screenPoint(0, 179.9, view),
    [b] = screenPoint(0, -179.9, view);
  expect(Math.abs(a - b)).toBeLessThan(750);
  expect(view.zoom).toBeGreaterThan(8);
});
test("real position and selected markers set focus; missing positions do not", () => {
  expect(
    initialView({ ...props, position: { latitude: 47, longitude: 8 } }).center,
  ).toEqual([47, 8]);
  expect(
    initialView({ ...props, position: { latitude: NaN, longitude: 8 } }).center,
  ).toEqual([46.82, 8.23]);
});
