import { useState } from "react";
import type {
  MapLayers,
  MapMarker,
  MapPosition,
  MapViewport,
  SituationMapProps,
} from "./MapTypes";
import { validCoordinate } from "./projection";
import { useMapInteraction } from "./useMapInteraction";
import { useMapSize } from "./useMapSize";
import { initialView, makeView, zoomView } from "./viewport";

export function useMapModel(props: SituationMapProps) {
  const { ref, aspect } = useMapSize();
  const base = initialView(props, aspect);
  const [changed, setChanged] = useState<MapViewport>();
  const [layers, setLayers] = useState<MapLayers>({
    public: true,
    personal: true,
    routes: true,
    labels: props.showMarkerLabels ?? true,
  });
  const [basemapId, setBasemapId] = useState("");
  const [failedUrl, setFailedUrl] = useState<string>();
  const view = changed?.key === base.key ? changed : base;
  const zoom = (delta: number) => setChanged(zoomView(view, delta));
  const move = (offset: [number, number]) =>
    setChanged(makeView(view.key, view.zoom, view.center, offset));
  const interaction = useMapInteraction(
    view,
    move,
    zoom,
    props.onPickDestination,
  );
  const basemap = props.basemaps?.find((item) => item.id === basemapId);
  const tileUrl = basemap?.tileUrl ?? props.tileUrl;
  const markers = props.markers.filter(
    (marker): marker is MapMarker & MapPosition =>
      validCoordinate(marker.latitude, marker.longitude) &&
      layers[marker.visibility === "personal" ? "personal" : "public"],
  );
  return {
    ...props,
    ref,
    aspect,
    markers,
    view,
    zoom,
    layers,
    setLayers,
    basemapId,
    setBasemapId,
    interaction,
    tileUrl,
    reset: () => setChanged(base),
    failed: !tileUrl || failedUrl === tileUrl,
    fail: () => setFailedUrl(tileUrl),
    attribution: basemap?.attribution ?? props.attribution,
    attributionUrl: basemap?.attributionUrl ?? props.attributionUrl,
  };
}
export type MapModel = ReturnType<typeof useMapModel>;
