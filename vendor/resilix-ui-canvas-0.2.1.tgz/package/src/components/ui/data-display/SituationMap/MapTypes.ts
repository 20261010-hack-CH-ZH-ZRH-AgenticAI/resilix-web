export interface MapPosition {
  latitude: number;
  longitude: number;
  accuracy_m?: number;
}
export interface MapMarker {
  id: string;
  title: string;
  latitude?: number | null;
  longitude?: number | null;
  category?: string;
  severity?: string;
  visibility?: string;
  is_simulation?: boolean;
}
export interface MapRoute {
  id: string;
  geometry: { type: "LineString"; coordinates: [number, number][] };
  distance_m: number;
  duration_s: number;
  profile: "foot" | "bike" | "car";
  provenance?: {
    provider: string;
    attribution: string;
    attribution_url: string;
    fix_map_url: string;
    safety_assessed: false;
  };
}
export interface MapBasemap {
  id: string;
  label: string;
  tileUrl: string;
  attribution: string;
  attributionUrl?: string;
}
export interface MapLabels {
  zoomIn: string;
  zoomOut: string;
  reset: string;
  unavailable: string;
  map: string;
  layers?: string;
  public?: string;
  personal?: string;
  routes?: string;
  labels?: string;
  location?: string;
  start?: string;
  end?: string;
  routePreview?: string;
  pickDestination?: string;
  markers?: string;
  basemap?: string;
  panHint?: string;
  fixMap?: string;
}
export interface SituationMapProps {
  markers: MapMarker[];
  tileUrl?: string;
  attribution: string;
  attributionUrl?: string;
  selected?: string;
  onSelect: (id: string) => void;
  center?: [number, number];
  labels: MapLabels;
  route?: MapRoute;
  position?: MapPosition;
  onPickDestination?: (position: MapPosition) => void;
  initialZoom?: number;
  basemaps?: MapBasemap[];
  showLayerControls?: boolean;
  showMarkerLabels?: boolean;
}
export interface MapViewport {
  key: string;
  zoom: number;
  center: [number, number];
  offset: [number, number];
  left: number;
  top: number;
}
export interface MapLayers {
  public: boolean;
  personal: boolean;
  routes: boolean;
  labels: boolean;
}
