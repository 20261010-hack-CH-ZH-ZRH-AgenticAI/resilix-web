import { MapGlyph, markerGlyph } from "./MapGlyph";
import type { MapMarker, MapPosition } from "./MapTypes";
import styles from "./SituationMapStyles.module.css";
import type { MapModel } from "./useMapModel";
import { screenPoint } from "./viewport";

function Marker({
  marker,
  model,
}: {
  marker: MapMarker & MapPosition;
  model: MapModel;
}) {
  const [x, y] = screenPoint(marker.latitude, marker.longitude, model.view);
  const width = Math.min(1200, 700 * model.aspect);
  const height = Math.min(700, 1200 / model.aspect);
  if (Math.abs(x - 600) > width / 2 || Math.abs(y - 350) > height / 2)
    return null;
  const selected = marker.id === model.selected;
  const showTitle = selected || (model.layers.labels && model.view.zoom >= 11);
  const personal = marker.visibility === "personal";
  return (
    <g
      transform={`translate(${x},${y})`}
      className={`${styles.marker} ${personal ? styles.personal : ""} ${selected ? styles.selected : ""}`}
    >
      <title>{marker.title}</title>
      <circle r={selected ? 28 : 23} className={styles.halo} />
      <circle r="17" className={styles.pin} />
      <foreignObject x="-22" y="-22" width="44" height="44">
        <button
          type="button"
          className={styles.markerButton}
          aria-label={marker.title}
          title={marker.title}
          aria-pressed={selected}
          onPointerDown={(event) => event.stopPropagation()}
          onClick={() => model.onSelect(marker.id)}
        >
          <MapGlyph name={markerGlyph(marker.category, personal)} />
        </button>
      </foreignObject>
      {showTitle && (
        <g className={styles.mapLabel}>
          <rect x="25" y="-16" width="192" height="32" rx="12" />
          <text x="37" y="5">
            {marker.title.length > 25
              ? `${marker.title.slice(0, 24)}…`
              : marker.title}
          </text>
        </g>
      )}
    </g>
  );
}

export function MapMarkers(model: MapModel) {
  return (
    <>
      {model.markers.map((marker) => (
        <Marker key={marker.id} marker={marker} model={model} />
      ))}
    </>
  );
}
