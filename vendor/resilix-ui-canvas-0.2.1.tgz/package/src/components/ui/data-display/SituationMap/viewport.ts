import type {
  MapMarker,
  MapPosition,
  MapRoute,
  MapViewport,
  SituationMapProps,
} from "./MapTypes";
import { nearbyX, project, unproject, validCoordinate } from "./projection";

export function routeCoordinates(route?: MapRoute): [number, number][] {
  if (route?.geometry.type !== "LineString") return [];
  const points = route.geometry.coordinates;
  return points.length >= 2 &&
    points.length <= 20_000 &&
    points.every(([lon, lat]) => validCoordinate(lat, lon))
    ? points
    : [];
}

function routeView(
  route: MapRoute,
  aspect: number,
): { center: [number, number]; zoom: number } | undefined {
  const coordinates = routeCoordinates(route);
  if (coordinates.length < 2) return;
  const anchor = project(coordinates[0][1], coordinates[0][0], 0)[0];
  const points = coordinates.map(([lon, lat]) => {
    const [x, y] = project(lat, lon, 0);
    return [nearbyX(x, anchor, 0), y];
  });
  const xs = points.map(([x]) => x);
  const ys = points.map(([, y]) => y);
  const minX = Math.min(...xs),
    maxX = Math.max(...xs);
  const minY = Math.min(...ys),
    maxY = Math.max(...ys);
  const zoom = Math.floor(
    Math.log2(
      Math.min(
        (Math.min(1200, 700 * aspect) * 0.65) / Math.max(maxX - minX, 0.001),
        (Math.min(700, 1200 / aspect) * 0.6) / Math.max(maxY - minY, 0.001),
      ),
    ),
  );
  return {
    center: unproject((minX + maxX) / 2, (minY + maxY) / 2, 0),
    zoom: Math.max(4, Math.min(17, zoom)),
  };
}

export function initialView(
  props: SituationMapProps,
  aspect = 1200 / 700,
): MapViewport {
  const selected = props.markers.find(
    (marker): marker is MapMarker & MapPosition =>
      marker.id === props.selected &&
      validCoordinate(marker.latitude, marker.longitude),
  );
  const located =
    props.position &&
    validCoordinate(props.position.latitude, props.position.longitude)
      ? props.position
      : undefined;
  const route = props.route && routeView(props.route, aspect);
  const center: [number, number] =
    route?.center ??
    (selected
      ? [selected.latitude, selected.longitude]
      : located
        ? [located.latitude, located.longitude]
        : (props.center ?? [46.82, 8.23]));
  const zoom =
    route?.zoom ?? (selected || located ? 14 : (props.initialZoom ?? 8));
  const key = `${props.route?.id ?? selected?.id ?? `${center[0]},${center[1]}`}:${aspect.toFixed(3)}`;
  return makeView(key, Math.max(4, Math.min(18, zoom)), center, [0, 0]);
}

export function makeView(
  key: string,
  zoom: number,
  center: [number, number],
  offset: [number, number],
): MapViewport {
  const [cx, cy] = project(center[0], center[1], zoom);
  return {
    key,
    zoom,
    center,
    offset,
    left: cx - 600 + offset[0],
    top: cy - 350 + offset[1],
  };
}

export function zoomView(view: MapViewport, delta: number): MapViewport {
  const zoom = Math.max(4, Math.min(18, view.zoom + delta));
  const ratio = 2 ** (zoom - view.zoom);
  return makeView(view.key, zoom, view.center, [
    view.offset[0] * ratio,
    view.offset[1] * ratio,
  ]);
}

export function screenPoint(
  latitude: number,
  longitude: number,
  view: MapViewport,
): [number, number] {
  const [x, y] = project(latitude, longitude, view.zoom);
  return [nearbyX(x, view.left + 600, view.zoom) - view.left, y - view.top];
}

export function positionAt(
  x: number,
  y: number,
  view: MapViewport,
): MapPosition {
  const [latitude, longitude] = unproject(
    view.left + x,
    view.top + y,
    view.zoom,
  );
  return { latitude, longitude };
}
