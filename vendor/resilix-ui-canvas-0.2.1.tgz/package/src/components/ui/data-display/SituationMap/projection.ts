export function project(
  latitude: number,
  longitude: number,
  zoom: number,
): [number, number] {
  const scale = 256 * 2 ** zoom;
  const sine = Math.sin(
    (Math.max(-85, Math.min(85, latitude)) * Math.PI) / 180,
  );
  return [
    ((longitude + 180) / 360) * scale,
    (0.5 - Math.log((1 + sine) / (1 - sine)) / (4 * Math.PI)) * scale,
  ];
}
export function validCoordinate(
  latitude?: number | null,
  longitude?: number | null,
): boolean {
  return (
    typeof latitude === "number" &&
    typeof longitude === "number" &&
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -85 &&
    latitude <= 85 &&
    longitude >= -180 &&
    longitude <= 180
  );
}

export function unproject(
  x: number,
  y: number,
  zoom: number,
): [number, number] {
  const scale = 256 * 2 ** zoom;
  const longitude =
    (((((x / scale) * 360 - 180 + 180) % 360) + 360) % 360) - 180;
  const latitude =
    (Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / scale))) * 180) / Math.PI;
  return [Math.max(-85, Math.min(85, latitude)), longitude];
}

export function nearbyX(x: number, anchor: number, zoom: number): number {
  const width = 256 * 2 ** zoom;
  return x + Math.round((anchor - x) / width) * width;
}

export function metersPerPixel(latitude: number, zoom: number): number {
  return (156543.03392 * Math.cos((latitude * Math.PI) / 180)) / 2 ** zoom;
}
