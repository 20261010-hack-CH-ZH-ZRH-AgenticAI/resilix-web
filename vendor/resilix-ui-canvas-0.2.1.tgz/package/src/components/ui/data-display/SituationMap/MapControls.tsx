import { MapGlyph, type MapGlyphName } from "./MapGlyph";
import type { MapLayers } from "./MapTypes";
import styles from "./SituationMapStyles.module.css";
import type { MapModel } from "./useMapModel";

function LayerButton({
  model,
  layer,
  icon,
  title,
}: {
  model: MapModel;
  layer: keyof MapLayers;
  icon: MapGlyphName;
  title: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={model.layers[layer]}
      title={title}
      onClick={() =>
        model.setLayers((value) => ({ ...value, [layer]: !value[layer] }))
      }
    >
      <MapGlyph name={icon} size={18} />
      <span>{title}</span>
    </button>
  );
}
export function MapLayerControls(model: MapModel) {
  if (model.showLayerControls === false) return null;
  return (
    <fieldset
      className={styles.layerControls}
      aria-label={model.labels.layers ?? "Map layers"}
    >
      <LayerButton
        model={model}
        layer="public"
        icon="warning"
        title={model.labels.public ?? "Public"}
      />
      <LayerButton
        model={model}
        layer="personal"
        icon="person"
        title={model.labels.personal ?? "Personal"}
      />
      <LayerButton
        model={model}
        layer="routes"
        icon="route"
        title={model.labels.routes ?? "Routes"}
      />
      <LayerButton
        model={model}
        layer="labels"
        icon="label"
        title={model.labels.labels ?? "Labels"}
      />
    </fieldset>
  );
}
export function MapNavigation(model: MapModel) {
  return (
    <div className={styles.controls}>
      {Boolean(model.basemaps?.length) && (
        <select
          className={styles.basemap}
          aria-label={model.labels.basemap ?? "Basemap"}
          value={model.basemapId}
          onChange={(event) => model.setBasemapId(event.target.value)}
        >
          <option value="">{model.labels.map}</option>
          {model.basemaps?.map((item) => (
            <option key={item.id} value={item.id}>
              {item.label}
            </option>
          ))}
        </select>
      )}
      <button
        type="button"
        aria-label={model.labels.zoomIn}
        title={model.labels.zoomIn}
        disabled={model.view.zoom >= 18}
        onClick={() => model.zoom(1)}
      >
        +
      </button>
      <button
        type="button"
        aria-label={model.labels.zoomOut}
        title={model.labels.zoomOut}
        disabled={model.view.zoom <= 4}
        onClick={() => model.zoom(-1)}
      >
        −
      </button>
      <button
        type="button"
        aria-label={model.labels.reset}
        title={model.labels.reset}
        onClick={model.reset}
      >
        <MapGlyph name="location" size={20} />
      </button>
    </div>
  );
}
export function MapStatus(model: MapModel) {
  const selected = model.markers.find((marker) => marker.id === model.selected);
  return (
    <>
      <div className={styles.markerCount}>
        <MapGlyph name="layers" size={15} />
        <span>
          {model.markers.length} {model.labels.markers ?? "markers"}
        </span>
      </div>
      {selected && (
        <div className={styles.selectedCard}>
          <span>
            {selected.visibility === "personal"
              ? (model.labels.personal ?? "Personal")
              : (model.labels.public ?? "Public")}
          </span>
          <strong>{selected.title}</strong>
        </div>
      )}
      {model.route && model.layers.routes && (
        <div className={styles.routeBadge}>
          <strong>
            {(model.route.distance_m / 1000).toFixed(1)} km ·{" "}
            {Math.ceil(model.route.duration_s / 60)} min
          </strong>
          <span>
            {model.labels.routePreview ?? "Route preview · safety not assessed"}
          </span>
        </div>
      )}
      {model.failed && (
        <output className={styles.failure}>{model.labels.unavailable}</output>
      )}
    </>
  );
}
