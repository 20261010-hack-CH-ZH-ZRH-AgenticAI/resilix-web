import { metersPerPixel, validCoordinate } from "./projection";
import styles from "./SituationMapStyles.module.css";
import type { MapModel } from "./useMapModel";
import { screenPoint } from "./viewport";

export function MapPositionLayer(model: MapModel) {
  const position = model.position;
  if (!position || !validCoordinate(position.latitude, position.longitude))
    return null;
  const [x, y] = screenPoint(position.latitude, position.longitude, model.view);
  const accuracy = position.accuracy_m;
  const radius =
    typeof accuracy === "number" && Number.isFinite(accuracy) && accuracy >= 0
      ? accuracy / metersPerPixel(position.latitude, model.view.zoom)
      : undefined;
  return (
    <g transform={`translate(${x},${y})`} className={styles.position}>
      <title>
        {`${model.labels.location ?? "Your location"}${radius !== undefined ? ` · ±${Math.round(accuracy ?? 0)} m` : ""}`}
      </title>
      {radius !== undefined && (
        <circle r={radius} className={styles.accuracy} />
      )}
      <circle r="13" className={styles.positionHalo} />
      <circle r="7" className={styles.positionDot} />
    </g>
  );
}
