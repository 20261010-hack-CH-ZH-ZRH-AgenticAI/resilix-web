import { expect, test } from "bun:test";
import { renderToStaticMarkup } from "react-dom/server";
import { SituationMap } from "./SituationMap";

const labels = {
  zoomIn: "Zoom in",
  zoomOut: "Zoom out",
  reset: "Reset map",
  unavailable: "Unavailable",
  map: "Situation map",
};
test("missing coordinates never become fabricated map markers", () => {
  const html = renderToStaticMarkup(
    <SituationMap
      markers={[{ id: "missing", title: "Private without location" }]}
      onSelect={() => undefined}
      attribution="swisstopo"
      labels={labels}
    />,
  );
  expect(html).not.toContain('aria-label="Private without location"');
  expect(html).toContain("swisstopo");
});
test("real coordinates expose a native keyboard-operable marker button", () => {
  const html = renderToStaticMarkup(
    <SituationMap
      markers={[
        { id: "real", title: "Observed point", latitude: 47, longitude: 8 },
      ]}
      onSelect={() => undefined}
      attribution="swisstopo"
      labels={labels}
    />,
  );
  expect(html).toContain('aria-label="Observed point"');
  expect(html).toContain("<button");
});

test("offscreen markers do not create invisible keyboard stops", () => {
  const html = renderToStaticMarkup(
    <SituationMap
      markers={[
        {
          id: "far",
          title: "Distant observation",
          latitude: 0,
          longitude: -80,
        },
      ]}
      center={[47.3769, 8.5417]}
      initialZoom={14}
      onSelect={() => undefined}
      attribution="swisstopo"
      labels={labels}
    />,
  );
  expect(html).not.toContain('aria-label="Distant observation"');
});

test("provider route, real accuracy, attribution and layer controls render together", () => {
  const html = renderToStaticMarkup(
    <SituationMap
      markers={[]}
      onSelect={() => undefined}
      attribution="swisstopo"
      labels={labels}
      position={{ latitude: 47.3769, longitude: 8.5417, accuracy_m: 12 }}
      route={{
        id: "fixture",
        geometry: {
          type: "LineString",
          coordinates: [
            [8.5417, 47.3769],
            [8.5481, 47.3763],
          ],
        },
        distance_m: 764.5,
        duration_s: 611.8,
        profile: "foot",
        provenance: {
          provider: "FOSSGIS OSRM",
          attribution: "© OpenStreetMap contributors (ODbL)",
          attribution_url: "https://www.openstreetmap.org/copyright",
          fix_map_url: "https://www.openstreetmap.org/fixthemap",
          safety_assessed: false,
        },
      }}
    />,
  );
  expect(html).toContain("<polyline");
  expect(html).toContain("±12 m");
  expect(html).toContain("safety not assessed");
  expect(html).toContain("OpenStreetMap contributors");
  expect(html).toContain('aria-label="Map layers"');
  expect(html).toContain('aria-pressed="true"');
});
