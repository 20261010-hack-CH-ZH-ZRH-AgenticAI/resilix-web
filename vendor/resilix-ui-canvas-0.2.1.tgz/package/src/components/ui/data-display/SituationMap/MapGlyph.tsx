export type MapGlyphName =
  | "warning"
  | "fire"
  | "earthquake"
  | "flood"
  | "medical"
  | "person"
  | "route"
  | "layers"
  | "label"
  | "location"
  | "flag";
const paths: Record<MapGlyphName, string> = {
  warning: "M12 3 2 21h20L12 3Zm0 6v5m0 3v1",
  fire: "M13 2c1 6-4 6-3 10-2-1-2-3-2-4-7 8-3 14 4 14s11-7 5-14c0 4-2 5-3 5 2-5 0-8-1-11Z",
  earthquake: "M2 13h5l2-7 4 14 3-10 2 3h4",
  flood:
    "M2 8c3-3 5 3 8 0s5 3 8 0 4 0 4 0M2 13c3-3 5 3 8 0s5 3 8 0 4 0 4 0M2 18c3-3 5 3 8 0s5 3 8 0 4 0 4 0",
  medical: "M9 3h6v6h6v6h-6v6H9v-6H3V9h6V3Z",
  person: "M12 3a3 3 0 1 0 0 6 3 3 0 0 0 0-6ZM5 21v-3a7 7 0 0 1 14 0v3",
  route: "M6 18a3 3 0 1 0 0 .1M18 3a3 3 0 1 0 0 .1M6 15V9a3 3 0 0 1 3-3h6",
  layers: "m12 3 10 6-10 6L2 9l10-6Zm-10 10 10 6 10-6M2 17l10 6 10-6",
  label: "M4 4h16v12H9l-5 5V4Zm4 4h8M8 12h5",
  location:
    "M12 2v3m0 14v3M2 12h3m14 0h3M12 5a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm0 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z",
  flag: "M5 22V3h13l-3 5 3 5H5",
};
export function markerGlyph(
  category?: string,
  personal?: boolean,
): MapGlyphName {
  if (personal) return "person";
  const key = category?.toLowerCase() ?? "";
  if (key.includes("fire")) return "fire";
  if (key.includes("earthquake")) return "earthquake";
  if (key.includes("flood") || key.includes("rain")) return "flood";
  if (key.includes("medical") || key.includes("health")) return "medical";
  return "warning";
}
export function MapGlyph({
  name,
  size = 18,
}: {
  name: MapGlyphName;
  size?: number;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d={paths[name]} />
    </svg>
  );
}
