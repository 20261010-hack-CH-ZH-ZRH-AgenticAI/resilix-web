import { expect, test } from "bun:test";
import { renderToStaticMarkup } from "react-dom/server";
import { VoiceOrb } from "./VoiceOrb";

test("voice control exposes actual state without creating media resources", () => {
  const html = renderToStaticMarkup(
    <VoiceOrb
      state="muted"
      label="Unmute voice"
      caption="Microphone muted"
      onToggle={() => {}}
    />,
  );
  expect(html).toContain('aria-pressed="true"');
  expect(html).toContain('data-state="muted"');
  expect(html).toContain('aria-label="Unmute voice"');
});
