import { forwardRef } from "react";
import styles from "./VoiceOrbStyles.module.css";

export interface VoiceOrbProps {
  state: "idle" | "connecting" | "listening" | "speaking" | "muted";
  label: string;
  caption: string;
  onToggle: () => void;
  disabled?: boolean;
}

export const VoiceOrb = forwardRef<HTMLButtonElement, VoiceOrbProps>(
  function VoiceOrb({ state, label, caption, onToggle, disabled }, ref) {
    return (
      <div className={styles.focus} data-state={state}>
        <button
          ref={ref}
          type="button"
          className={styles.orb}
          onClick={onToggle}
          disabled={disabled}
          aria-label={label}
          aria-pressed={state !== "idle"}
          aria-busy={state === "connecting"}
          title={label}
        >
          <span className={styles.halo} aria-hidden="true" />
          <span className={styles.core} aria-hidden="true">
            <svg
              width="42"
              height="42"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              aria-hidden="true"
            >
              {state === "idle" ? (
                <path d="M9 5a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0V5ZM5 11v1a7 7 0 0 0 14 0v-1M12 19v3M9 22h6" />
              ) : (
                <path d="M3 10v4m4-7v10m5-14v18m5-14v10m4-7v4" />
              )}
            </svg>
          </span>
        </button>
        <strong>{label}</strong>
        <output className={styles.caption}>{caption}</output>
      </div>
    );
  },
);
