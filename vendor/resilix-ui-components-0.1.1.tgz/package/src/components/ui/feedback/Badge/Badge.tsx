import type { ReactNode } from "react";
import styles from "./BadgeStyles.module.css";
export function Badge({
  children,
  tone = "neutral",
  dot = false,
}: {
  children: ReactNode;
  tone?: "neutral" | "lime" | "warning" | "danger" | "purple";
  dot?: boolean;
}) {
  return (
    <span className={`${styles.badge} ${styles[tone]}`}>
      {dot && <span className={styles.dot} />}
      {children}
    </span>
  );
}
