import type { SVGProps } from "react";

export type IconName =
  | "shield"
  | "map"
  | "chat"
  | "bell"
  | "grid"
  | "arrow"
  | "plus"
  | "close"
  | "sun"
  | "moon"
  | "globe"
  | "pin"
  | "mic"
  | "image"
  | "send"
  | "logout"
  | "chevron"
  | "check"
  | "lock"
  | "wave"
  | "layers"
  | "external"
  | "refresh"
  | "download"
  | "mountain"
  | "spark"
  | "stop"
  | "trash";
const paths: Record<IconName, string> = {
  shield: "M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6l-8-3Zm-4 9 3 3 5-6",
  map: "m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2V5Zm6-2v16m6-14v16",
  chat: "M21 11a9 9 0 0 1-9 9H4l-3 2 2-6a9 9 0 1 1 18-5ZM7 10h10M7 14h6",
  bell: "M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4",
  grid: "M3 3h7v7H3V3Zm11 0h7v7h-7V3ZM3 14h7v7H3v-7Zm11 0h7v7h-7v-7Z",
  arrow: "M4 12h16m-6-6 6 6-6 6",
  plus: "M12 4v16M4 12h16",
  close: "m6 6 12 12M6 18 18 6",
  sun: "M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
  moon: "M20 14A9 9 0 0 1 10 3a9 9 0 1 0 10 11Z",
  globe:
    "M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18Z",
  pin: "M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Zm-5 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",
  mic: "M9 5a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0V5Zm-4 6v1a7 7 0 0 0 14 0v-1M12 19v3M9 22h6",
  image: "M3 3h18v18H3V3Zm0 14 6-6 4 4 3-3 5 5M8 7h.01",
  send: "m4 20 8-16 8 16-8-4-8 4Zm8-16v12",
  logout: "M9 3H3v18h6m0-9h12m-5-5 5 5-5 5",
  chevron: "m8 4 8 8-8 8",
  check: "m5 12 4 4L19 6",
  lock: "M5 10h14v11H5V10Zm3 0V6a4 4 0 1 1 8 0v4M12 14v3",
  wave: "M3 10v4m4-7v10m5-14v18m5-14v10m4-7v4",
  layers: "m12 3 10 5-10 5L2 8l10-5ZM2 12l10 5 10-5M2 16l10 5 10-5",
  external: "M14 3h7v7m0-7-11 11M10 3H3v18h18v-7",
  refresh: "M20 7V2l-3 3a9 9 0 1 0 3 12M20 2h-5",
  download: "M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5",
  mountain: "m2 20 7-13 4 7 3-11 6 17H2ZM7 11l2 2 2-2m3-2 2 2 2-2",
  spark: "m12 3 2 6 7 3-7 2-2 7-2-7-7-2 7-3 2-6Z",
  stop: "M5 5h14v14H5V5Z",
  trash: "M3 6h18M8 6V3h8v3M5 6l1 15h12l1-15M10 10v7m4-7v7",
};
export function Icon({
  name,
  ...props
}: SVGProps<SVGSVGElement> & { name: IconName }) {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      <path d={paths[name]} />
    </svg>
  );
}
