import type { ReactNode } from "react";
import styles from "./MetricCardStyles.module.css";
export function MetricCard({
  label,
  value,
  detail,
  icon,
  accent = false,
}: {
  label: string;
  value: ReactNode;
  detail: string;
  icon?: ReactNode;
  accent?: boolean;
}) {
  return (
    <article className={`${styles.card} ${accent ? styles.accent : ""}`}>
      <div className={styles.heading}>
        <span>{label}</span>
        {icon}
      </div>
      <strong className={styles.value}>{value}</strong>
      <span className={styles.detail}>{detail}</span>
    </article>
  );
}
