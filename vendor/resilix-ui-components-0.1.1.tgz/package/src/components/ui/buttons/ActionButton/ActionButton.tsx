import type { ButtonHTMLAttributes, Ref } from "react";
import styles from "./ActionButtonStyles.module.css";
export interface ActionButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "accent" | "ghost" | "danger";
  compact?: boolean;
  ref?: Ref<HTMLButtonElement>;
}
export function ActionButton({
  children,
  variant = "primary",
  compact,
  className = "",
  ref,
  ...props
}: ActionButtonProps) {
  return (
    <button
      type="button"
      ref={ref}
      className={`${styles.button} ${styles[variant]} ${compact ? styles.compact : ""} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
