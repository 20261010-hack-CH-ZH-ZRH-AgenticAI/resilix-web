import { expect, test } from "bun:test";
import { renderToStaticMarkup } from "react-dom/server";
import { ActionButton } from "./ActionButton";

test("controls default to a non-submitting button and preserve accessibility props", () => {
  const html = renderToStaticMarkup(
    <ActionButton disabled aria-label="Send message">
      Send
    </ActionButton>,
  );
  expect(html).toContain('type="button"');
  expect(html).toContain('aria-label="Send message"');
  expect(html).toContain("disabled");
});
