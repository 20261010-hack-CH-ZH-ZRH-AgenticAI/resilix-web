import type { ReactNode } from "react";
import styles from "./EntityMessageStyles.module.css";
export interface EntityMessageProps {
  name: string;
  emblem: ReactNode;
  tone?: "neutral" | "lime" | "purple" | "danger" | "warning";
  simulationLabel?: string;
  timeLabel?: string;
  children: ReactNode;
  actions?: ReactNode;
}
export function EntityMessage({
  name,
  emblem,
  tone = "neutral",
  simulationLabel,
  timeLabel,
  children,
  actions,
}: EntityMessageProps) {
  return (
    <article className={styles.message} data-tone={tone}>
      <div className={styles.avatar} aria-hidden="true">
        {emblem}
      </div>
      <div className={styles.body}>
        <header className={styles.header}>
          <strong>{name}</strong>
          {simulationLabel && <span>{simulationLabel}</span>}
          {timeLabel && <small>{timeLabel}</small>}
        </header>
        <div className={styles.content}>{children}</div>
        {actions && <footer className={styles.actions}>{actions}</footer>}
      </div>
    </article>
  );
}
