import { expect, test } from "bun:test";
import { renderToStaticMarkup } from "react-dom/server";
import { ActivityTrace } from "../../data-display/ActivityTrace/ActivityTrace";
import { EntityMessage } from "./EntityMessage";

test("simulated entities are labeled and activity text is escaped", () => {
  const html = renderToStaticMarkup(
    <EntityMessage name="Medical" emblem="+" simulationLabel="Simulation">
      <ActivityTrace
        label="Activity"
        description="Actual tool output"
        entries={[
          {
            id: "1",
            label: "Tool",
            status: "failed",
            details: "<script>secret()</script>",
          },
        ]}
      />
    </EntityMessage>,
  );
  expect(html).toContain("Simulation");
  expect(html).toContain("&lt;script&gt;");
  expect(html).not.toContain("<script>");
  expect(html).toContain("<summary>");
});
