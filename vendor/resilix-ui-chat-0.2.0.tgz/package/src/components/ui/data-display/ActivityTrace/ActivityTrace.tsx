import styles from "./ActivityTraceStyles.module.css";
export interface ActivityEntry {
  id: string;
  label: string;
  status: string;
  details: string;
  time?: string;
}
export function ActivityTrace({
  entries,
  label,
  description,
}: {
  entries: ActivityEntry[];
  label: string;
  description: string;
}) {
  return (
    <details className={styles.trace}>
      <summary>
        {label}
        <span>{entries.length}</span>
      </summary>
      <p>{description}</p>
      <ol>
        {entries.map((entry) => (
          <li key={entry.id}>
            <details>
              <summary>
                <strong>{entry.label}</strong>
                <span>{entry.status}</span>
                {entry.time && <time>{entry.time}</time>}
              </summary>
              <pre>{entry.details}</pre>
            </details>
          </li>
        ))}
      </ol>
    </details>
  );
}
