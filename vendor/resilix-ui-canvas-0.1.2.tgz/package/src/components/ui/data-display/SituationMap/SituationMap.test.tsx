import { expect, test } from "bun:test";
import { renderToStaticMarkup } from "react-dom/server";
import { SituationMap } from "./SituationMap";

const labels = {
  zoomIn: "Zoom in",
  zoomOut: "Zoom out",
  reset: "Reset map",
  unavailable: "Unavailable",
  map: "Situation map",
};
test("missing coordinates never become fabricated map markers", () => {
  const html = renderToStaticMarkup(
    <SituationMap
      markers={[{ id: "missing", title: "Private without location" }]}
      onSelect={() => undefined}
      attribution="swisstopo"
      labels={labels}
    />,
  );
  expect(html).not.toContain('aria-label="Private without location"');
  expect(html).toContain("swisstopo");
});
test("real coordinates expose a native keyboard-operable marker button", () => {
  const html = renderToStaticMarkup(
    <SituationMap
      markers={[
        { id: "real", title: "Observed point", latitude: 47, longitude: 8 },
      ]}
      onSelect={() => undefined}
      attribution="swisstopo"
      labels={labels}
    />,
  );
  expect(html).toContain('aria-label="Observed point"');
  expect(html).toContain("<button");
});
