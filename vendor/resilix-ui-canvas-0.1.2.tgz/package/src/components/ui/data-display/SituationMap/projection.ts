export function project(
  latitude: number,
  longitude: number,
  zoom: number,
): [number, number] {
  const scale = 256 * 2 ** zoom;
  const sine = Math.sin(
    (Math.max(-85, Math.min(85, latitude)) * Math.PI) / 180,
  );
  return [
    ((longitude + 180) / 360) * scale,
    (0.5 - Math.log((1 + sine) / (1 - sine)) / (4 * Math.PI)) * scale,
  ];
}
export function validCoordinate(
  latitude?: number | null,
  longitude?: number | null,
): boolean {
  return (
    typeof latitude === "number" &&
    typeof longitude === "number" &&
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -85 &&
    latitude <= 85 &&
    longitude >= -180 &&
    longitude <= 180
  );
}
