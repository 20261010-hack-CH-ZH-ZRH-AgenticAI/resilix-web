"use client";
import { useState } from "react";
import { project, validCoordinate } from "./projection";
import styles from "./SituationMapStyles.module.css";
export interface MapMarker {
  id: string;
  title: string;
  latitude?: number | null;
  longitude?: number | null;
  severity?: string;
  visibility?: string;
  is_simulation?: boolean;
}
export interface SituationMapProps {
  markers: MapMarker[];
  tileUrl?: string;
  attribution: string;
  attributionUrl?: string;
  selected?: string;
  onSelect: (id: string) => void;
  center?: [number, number];
  labels: {
    zoomIn: string;
    zoomOut: string;
    reset: string;
    unavailable: string;
    map: string;
  };
}
export function SituationMap({
  markers,
  tileUrl,
  attribution,
  attributionUrl,
  selected,
  onSelect,
  center = [46.82, 8.23],
  labels,
}: SituationMapProps) {
  const [zoom, setZoom] = useState(8);
  const [offset, setOffset] = useState([0, 0]);
  const [failed, setFailed] = useState(false);
  const chosen = markers.find(
    (marker) =>
      marker.id === selected &&
      validCoordinate(marker.latitude, marker.longitude),
  );
  const [cx, cy] = project(
    chosen?.latitude ?? center[0],
    chosen?.longitude ?? center[1],
    zoom,
  );
  const left = cx - 600 + offset[0];
  const top = cy - 350 + offset[1];
  const tiles: { x: number; y: number; url: string }[] = [];
  if (tileUrl)
    for (let y = Math.floor(top / 256); y <= Math.floor((top + 700) / 256); y++)
      for (
        let x = Math.floor(left / 256);
        x <= Math.floor((left + 1200) / 256);
        x++
      )
        tiles.push({
          x,
          y,
          url: tileUrl
            .replace("{z}", `${zoom}`)
            .replace("{x}", `${x}`)
            .replace("{y}", `${y}`),
        });
  return (
    <div className={styles.map}>
      <svg
        className={styles.canvas}
        viewBox="0 0 1200 700"
        preserveAspectRatio="xMidYMid slice"
        aria-label={labels.map}
      >
        <title>{labels.map}</title>
        <rect width="1200" height="700" className={styles.backdrop} />
        {tiles.map((tile) => (
          <image
            key={`${zoom}-${tile.x}-${tile.y}`}
            href={tile.url}
            crossOrigin="anonymous"
            x={tile.x * 256 - left}
            y={tile.y * 256 - top}
            width="256"
            height="256"
            onError={() => setFailed(true)}
          />
        ))}
        {markers
          .filter((marker) =>
            validCoordinate(marker.latitude, marker.longitude),
          )
          .map((marker) => {
            const [x, y] = project(marker.latitude!, marker.longitude!, zoom);
            return (
              <g
                key={marker.id}
                className={`${styles.marker} ${marker.visibility === "personal" ? styles.personal : ""}`}
                transform={`translate(${x - left},${y - top})`}
              >
                <title>{marker.title}</title>
                <circle
                  r={marker.id === selected ? 27 : 22}
                  className={styles.halo}
                />
                <circle r="12" className={styles.pin} />
                <text y="5" textAnchor="middle" className={styles.pinText}>
                  {marker.visibility === "personal" ? "P" : "!"}
                </text>
                <foreignObject x="-22" y="-22" width="44" height="44">
                  <button
                    type="button"
                    className={styles.markerButton}
                    aria-label={marker.title}
                    title={marker.title}
                    onClick={() => onSelect(marker.id)}
                  />
                </foreignObject>
              </g>
            );
          })}
      </svg>
      <div className={styles.controls}>
        <button
          type="button"
          onClick={() => setZoom(Math.min(zoom + 1, 12))}
          title={labels.zoomIn}
          aria-label={labels.zoomIn}
        >
          +
        </button>
        <button
          type="button"
          onClick={() => setZoom(Math.max(zoom - 1, 6))}
          title={labels.zoomOut}
          aria-label={labels.zoomOut}
        >
          −
        </button>
        <button
          type="button"
          onClick={() => {
            setZoom(8);
            setOffset([0, 0]);
          }}
          title={labels.reset}
          aria-label={labels.reset}
        >
          ⌖
        </button>
      </div>
      {(!tileUrl || failed) && (
        <span className={styles.failure}>{labels.unavailable}</span>
      )}
      <div className={styles.attribution}>
        {attributionUrl?.startsWith("https://") ? (
          <a href={attributionUrl} target="_blank" rel="noopener noreferrer">
            {attribution}
          </a>
        ) : (
          attribution
        )}
      </div>
    </div>
  );
}
