import { expect, test } from "bun:test";
import { project, validCoordinate } from "./projection";

test("Web Mercator puts the equator and Greenwich at the world center", () => {
  expect(project(0, 0, 0)).toEqual([128, 128]);
});
test("coordinate boundary rejects missing, out-of-range and non-finite positions", () => {
  expect(validCoordinate(undefined, 0)).toBe(false);
  expect(validCoordinate(91, 0)).toBe(false);
  expect(validCoordinate(47, Infinity)).toBe(false);
  expect(validCoordinate(47.3, 8.5)).toBe(true);
});
test("Swiss coordinates remain finite at every supported zoom", () => {
  for (let zoom = 6; zoom <= 12; zoom++)
    expect(project(46.82, 8.23, zoom).every(Number.isFinite)).toBe(true);
});
