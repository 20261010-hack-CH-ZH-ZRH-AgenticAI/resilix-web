# Resilix UI chat

Independent Bun / Next.js / TypeScript component package and showcase. CSS Modules use the Resilix token vocabulary in `src/styles/globals.css`. The design follows the supplied gray/lime UI references, with accessible controls and light/dark tokens.

Run `bun install --frozen-lockfile`, `bun run build`, `bun run start`. Run `bun test` for package checks. This repository builds from its own checkout.

`bun pm pack` creates the source package exported by `src/index.ts`. The main Resilix web app carries a versioned tarball in its own `vendor/` directory, so no sibling checkout or unpublished Git revision is needed at build time. Repack after changing exported components, copy the archive to the consumer and reinstall its pinned local tarball.

No API keys belong here. This package contains presentation-only components; the consumer owns authentication and provider calls. CSS Modules are the sole component styling approach.

`docker-compose.yml` is for local development only. Production uses Azure Container Apps.
