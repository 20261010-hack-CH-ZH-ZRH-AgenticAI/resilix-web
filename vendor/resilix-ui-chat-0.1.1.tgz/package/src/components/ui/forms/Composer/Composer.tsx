"use client";
import type { ReactNode } from "react";
import styles from "./ComposerStyles.module.css";
export interface ComposerProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  busy?: boolean;
  placeholder: string;
  sendLabel: string;
  children?: ReactNode;
  hint?: string;
}
export function Composer({
  value,
  onChange,
  onSend,
  busy,
  placeholder,
  sendLabel,
  children,
  hint,
}: ComposerProps) {
  return (
    <div className={styles.wrap}>
      <div className={styles.composer}>
        <textarea
          aria-label={placeholder}
          placeholder={placeholder}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          maxLength={12000}
          rows={3}
          onKeyDown={(event) => {
            if (
              event.key === "Enter" &&
              !event.shiftKey &&
              !event.nativeEvent.isComposing
            ) {
              event.preventDefault();
              if (value.trim() && !busy) onSend();
            }
          }}
        />
        <div className={styles.toolbar}>
          <div className={styles.tools}>{children}</div>
          <button
            type="button"
            title={sendLabel}
            aria-label={sendLabel}
            disabled={busy || !value.trim()}
            onClick={onSend}
            className={styles.send}
          >
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              aria-hidden="true"
            >
              <path d="M12 20V4m-6 6 6-6 6 6" />
            </svg>
          </button>
        </div>
      </div>
      {hint && <p className={styles.hint}>{hint}</p>}
    </div>
  );
}
