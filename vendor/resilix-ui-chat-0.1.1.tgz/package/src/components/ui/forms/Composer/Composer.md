# Composer

Presentation-only Resilix component. The consuming application supplies data and callbacks; this component never calls provider or account APIs. Styling uses CSS Modules and host-provided Resilix semantic tokens. Native interactive controls preserve labels, keyboard activation and disabled state.

Exported through `src/index.ts`; use the independent showcase at `/` to inspect rendering.
