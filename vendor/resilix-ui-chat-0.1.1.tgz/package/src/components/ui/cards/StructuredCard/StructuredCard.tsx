import styles from "./StructuredCardStyles.module.css";
export interface AssistantCard {
  type?: string;
  title: string;
  body?: string;
  description?: string;
  items?: (string | { label?: string; value?: string; text?: string })[];
  steps?: string[];
  severity?: string;
  source_url?: string;
  source?: string;
  sources?: { title: string; url: string }[];
  image_url?: string;
}
function secureUrl(value?: string, image = false): string | undefined {
  if (!value) return undefined;
  if (
    image &&
    /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value)
  )
    return value;
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? url.href : undefined;
  } catch {
    return undefined;
  }
}
export function StructuredCard({
  card,
  sourceLabel,
}: {
  card: AssistantCard;
  sourceLabel: string;
}) {
  const source = secureUrl(card.source_url || card.sources?.[0]?.url);
  const image = secureUrl(card.image_url, true);
  const items = card.items ?? card.steps ?? [];
  return (
    <article className={styles.card} data-type={card.type ?? "information"}>
      <div className={styles.header}>
        <span className={styles.symbol}>✧</span>
        <h3>{card.title}</h3>
        {card.severity && <span className={styles.level}>{card.severity}</span>}
      </div>
      {(card.body || card.description) && (
        <p>{card.body || card.description}</p>
      )}
      {items.length > 0 && (
        <ul>
          {items.map((item, index) => (
            <li
              key={`${index}-${typeof item === "string" ? item : item.label}`}
            >
              <span className={styles.number}>
                {String(index + 1).padStart(2, "0")}
              </span>
              <span>
                {typeof item === "string"
                  ? item
                  : [item.label, item.value ?? item.text]
                      .filter(Boolean)
                      .join(": ")}
              </span>
            </li>
          ))}
        </ul>
      )}
      {image && <img src={image} alt={card.title} className={styles.image} />}
      {source && (
        <a href={source} target="_blank" rel="noopener noreferrer">
          {card.source || card.sources?.[0]?.title || sourceLabel} ↗
        </a>
      )}
    </article>
  );
}
