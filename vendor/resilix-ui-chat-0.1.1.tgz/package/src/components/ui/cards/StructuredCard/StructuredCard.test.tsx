import { expect, test } from "bun:test";
import { renderToStaticMarkup } from "react-dom/server";
import { StructuredCard } from "./StructuredCard";

test("hostile source schemes and HTML are never rendered as executable content", () => {
  const html = renderToStaticMarkup(
    <StructuredCard
      sourceLabel="Source"
      card={{
        title: "<script>alert(1)</script>",
        source_url: "javascript:alert(1)",
        items: ["Check source"],
      }}
    />,
  );
  expect(html).not.toContain('href="javascript:');
  expect(html).toContain("&lt;script&gt;");
  expect(html).toContain("Check source");
});
test("source arrays retain a safe primary citation", () => {
  const html = renderToStaticMarkup(
    <StructuredCard
      sourceLabel="Source"
      card={{
        title: "Report",
        sources: [{ title: "SLF", url: "https://www.slf.ch/" }],
      }}
    />,
  );
  expect(html).toContain('href="https://www.slf.ch/"');
  expect(html).toContain('rel="noopener noreferrer"');
});
